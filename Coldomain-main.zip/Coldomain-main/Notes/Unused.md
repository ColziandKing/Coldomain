Unused

domain # United Domain 
    This is composed of nations that are not major or key civilizations as Colziand, Salumi and Salveo.
rhuffelj
	raheiwlan
	orlegciuhn
	okhu-burrank
	Divinestria
	
    as miss beezlebub likes
	
  planetarium,
	sky dome/ theather

    adjective Servws, religious, restaurant market
    # United Domain 
    This is composed of nations that are not major or key civilizations as Colziand, Salumi and Salveo.
Dorgainnodus Servwhann, Naigdor is city. zeikond
    
255,204,255
unused "Receive a free [Settler] when you discover [Bronze Working]"] "Receive a free [Settler] when you discover [Mining]",  does not work
"Receive free [Great Scientist] when you discover [Writing]", 
"May choose [2] additional belief(s) of any type when [founding] a religion",
"When conquering an encampment, earn [25] Gold and recruit a Barbarian unit <with [67]% chance>","[-25]% maintenance costs <for [Land] units>",
"[-66]% maintenance costs <for [Water] units>","When defeating a [{Barbarian} {Water}] unit, earn [25] Gold and recruit it <with [50]% chance>",
bootleg of maya calendar not anymore

industrial and scientific civs

	 //Bonus//
	
			  
			   
			   
			   
		"[+3 Gold] <for [Military] units> <for every [1] [Remaining [Major] Civilizations]> <when number of [Remaining [City-states] Civilizations] is between [1] and [10]>",
		"[+30 Gold] <for [Military] units> <when number of [Remaining [City-states] Civilizations] is more than [10]>",
		
			   for de civ
			   great personification, Astronomy"Great Sage", Botany"Unused", Chemistry"Great Scientist", Engineering"Great Engineer", Education"Great Administrator", Steel"Great General", Currency"Great Merchant" 
			   (origin)Horseback Riding"Great General", Engineering"Great Engineer", Currency"Great Merchant", Drama and Poetry"Great Artist", Philosophy"Great Scientist", Theology"Great Phrophet

	
			   
			   copies of the old stuff during pandemic covid
			   
			  [
     {
		//nations
		"name": "Babylon",
		"leaderName": "Nebuchadnezzar II",
		"adjective": ["Babylonian"],
		"startBias": ["Avoid [Tundra]"],
		"preferredVictoryType": "Scientific",

		"startIntroPart1": "May the blessings of heaven be upon you, O great Nebuchadnezzar, father of mighty and ancient Babylon! Young was the world when Sargon built Babylon some five thousand years ago, long did it grow and prosper, gaining its first empire the eighteenth century BC, under godlike Hammurabi, the giver of law. Although conquered by the Kassites and then by the Assyrians, Babylon endured, emerging phoenix-like from its ashes of destruction and regaining its independence despite its many enemies. Truly was Babylon the center of arts and learning in the ancient world. O Nebuchadnezzar, your empire endured but a short time after your death, falling to the mighty Persians, and then to the Greeks, until the great city was destroyed by 141 BC.",
		"startIntroPart2": "But is Babylon indeed gone forever, great Nebuchadnezzar? Your people look to you to bring the empire back to life once more. Will you accept the challenge? Will you build a civilization that will stand the test of time?",

		"declaringWar": "The demon wants the blood of soldiers!",
		"attacked": "Oh well, I presume you know what you're doing.",
		"defeated": "It is over. Perhaps now I shall have peace, at last.",
		"introduction": "Are you real or a phantom?",

		"neutralHello": "Greetings.",
		"hateHello": "What do YOU want?!",

		"tradeRequest": "It appears that you do have a reason for existing – to make this deal with me.",

		"outerColor": [27,53,63],
		"innerColor": [213,249,255],
		"favoredReligion": "Islam",
		"uniqueName": "Ingenuity",
		"uniques": ["Receive free [Great Scientist] when you discover [Writing]", "[Great Scientist] is earned [50]% faster",
			    "[+5 Faith, +5 Gold, +5 Culture, +5 Happiness, +5 Production, +5 Science] from [All] tiles [in all cities]",
			    "[+10 Culture] from [All] tiles [in all cities]","[+10 Gold] from [All] tiles [in all cities]",
			    "[+10 Faith] from [All] tiles [in all cities]","[+10 Production] from [All] tiles [in all cities]",
			    "[+10 Science] from [All] tiles [in all cities]","[+10 Happiness] from [All] tiles [in all cities]",
			    "May choose [1] additional belief(s) of any type when [founding] a religion"],
		"cities": ["Babylon","Akkad","Dur-Kurigalzu","Nippur","Borsippa","Sippar","Opis","Mari","Shushan","Eshnunna",
			"Ellasar","Erech","Kutha","Sirpurla","Neribtum","Ashur","Ninveh","Nimrud","Arbela","Nuzi",
			"Arrapkha","Tutub","Shaduppum","Rapiqum","Mashkan Shapir","Tuttul","Ramad","Ana","Haradum","Agrab",
			"Uqair","Gubba","Hafriyat","Nagar","Shubat Enlil","Urhai","Urkesh","Awan","Riblah","Tayma"]
	},
	{
		"name": "Russia",
		"leaderName": "Catherine",
		"adjective": ["Russian"],
		"startBias": ["Tundra"],
		"preferredVictoryType": "Scientific",

		"startIntroPart1": "Greetings upon thee, Your Imperial Majesty Catherine, wondrous Empress of all the Russias. At your command lies the largest country in the world. Mighty Russia stretches from the Pacific Ocean in the east to the Baltic Sea in the west. Despite wars, droughts, and every manner of disaster the heroic Russian people survive and prosper, their artists and scientists among the best in the world. The Empire today remains one of the strongest ever seen in human history - a true superpower, with the greatest destructive force ever devised at her command.",
		"startIntroPart2": "Catherine, your people look to you to bring forth glorious days for Russia and her people, to revitalize the land and recapture the wonder of the Enlightenment. Will you lead your people once more into greatness? Can you build a civilization that will stand the test of time?",
		"declaringWar": "You've behaved yourself very badly, you know it. Now it's payback time.",
		"attacked": "You've mistaken my passion for a weakness, you'll regret about this.",
		"defeated": "We were defeated, so this makes me your prisoner. I suppose there are worse fates.",
		"introduction": "I greet you, stranger! If you are as intelligent and tactful as you are attractive, we'll get along just fine.",
		"neutralHello": "Hello!",
		"hateHello": "What do you need?!",
		"tradeRequest": "How would you like it if I propose this kind of exchange?",
		"outerColor": [ 236, 178, 0],
		"innerColor": [0,0,0],
		"favoredReligion": "Christianity",
		"uniqueName": "Siberian Riches",
		"uniques": ["[+1 Production] from every [Strategic resource]","Double quantity of [Horses] produced",
			"Double quantity of [Iron] produced","Double quantity of [Uranium] produced",
			    "[+5 Faith, +5 Gold, +5 Culture, +5 Happiness, +5 Production, +5 Science] from [All] tiles [in all cities]",
			    "[+10 Culture] from [All] tiles [in all cities]","[+10 Gold] from [All] tiles [in all cities]",
			    "[+10 Faith] from [All] tiles [in all cities]","[+10 Production] from [All] tiles [in all cities]",
			    "[+10 Science] from [All] tiles [in all cities]","[+10 Happiness] from [All] tiles [in all cities]",
			    "May choose [1] additional belief(s) of any type when [founding] a religion"],
		"cities": ["Moscow","St. Petersburg","Novgorod","Rostov","Yaroslavl","Yekaterinburg","Yakutsk","Vladivostok","Smolensk","Orenburg",
			"Krasnoyarsk","Khabarovsk","Bryansk","Tver","Novosibirsk","Magadan","Murmansk","Irkutsk","Chita","Samara",
			"Arkhangelsk","Chelyabinsk","Tobolsk","Vologda","Omsk","Astrakhan","Kursk","Saratov","Tula","Vladimir","Perm",
			"Voronezh","Pskov","Starayarussa","Kostoma","Nizhniy Novgorod","Suzdal","Magnitogorsk"]
	},
	{
		"name": "Japan",
		"leaderName": "Oda Nobunaga",
		"adjective": ["Japanese"],
		"startBias": ["Coast"],
		"preferredVictoryType": "Domination",

		"startIntroPart1": "Blessings upon you, noble Oda Nobunaga, ruler of Japan, the land of the Rising Sun! May you long walk among its flowering blossoms. The Japanese are an island people, proud and pious with a rich culture of arts and letters. Your civilization stretches back thousands of years, years of bloody warfare, expansion and isolation, great wealth and great poverty. In addition to their prowess on the field of battle, your people are also immensely industrious, and their technological innovation and mighty factories are the envy of lesser people everywhere.",
		"startIntroPart2": "Legendary daimyo, will you grab the reins of destiny? Will you bring your family and people the honor and glory they deserve? Will you once again pick up the sword and march to triumph? Will you build a civilization that stands the test of time?",
		"declaringWar": "I hereby inform you of our intention to wipe out your civilization from this world.",
		"attacked": "Pitiful fool! Now we shall destroy you!",
		"defeated": "You were much wiser than I thought.",
		"introduction": "We hope for a fair and just relationship with you, who are renowned for military bravery.",
		"neutralHello": "Hello.",
		"hateHello": "Oh, it's you...",
		"tradeRequest": "I would be grateful if you agreed on the following proposal.",
		"outerColor": [215,225,225],
		"innerColor": [185,0,0],
		"favoredReligion": "Shinto",
		"uniqueName": "Bushido",
		"uniques": ["Damage is ignored when determining unit Strength <for [non-air] units>",
			    "[+5 Faith, +5 Gold, +5 Culture, +5 Happiness, +5 Production, +5 Science] from [All] tiles [in all cities]",
			    "[+10 Culture] from [All] tiles [in all cities]","[+10 Gold] from [All] tiles [in all cities]",
			    "[+10 Faith] from [All] tiles [in all cities]","[+10 Production] from [All] tiles [in all cities]",
			    "[+10 Science] from [All] tiles [in all cities]","[+10 Happiness] from [All] tiles [in all cities]",
			    "May choose [1] additional belief(s) of any type when [founding] a religion"],
		"cities": ["Kyoto","Osaka","Tokyo","Satsuma","Kagoshima","Nara","Nagoya","Izumo","Nagasaki","Yokohama",
			"Shimonoseki","Matsuyama","Sapporo","Hakodate","Ise","Toyama","Fukushima","Suo","Bizen","Echizen",
			"Izumi","Omi","Echigo","Kozuke","Sado","Kobe","Nagano","Hiroshima","Takayama","Akita","Fukuoka","Aomori",
			"Kamakura","Kochi","Naha","Sendai","Gifu","Yamaguchi","Ota","Tottori"]
	},
{
		"name": "Germany",
		"leaderName": "Otto von Bismarck",
		"adjective": ["German"],
		"preferredVictoryType": "Scientific",

		"startIntroPart1": "Hail mighty Bismarck, first chancellor of Germany and her empire! Germany is an upstart nation, fashioned from the ruins of the Holy Roman Empire and finally unified in 1871, a little more than a century ago. The German people have proven themselves to be creative, industrious and ferocious warriors. Despite enduring great catastrophes in the first half of the 20th century, Germany remains a worldwide economic, artistic and technological leader.",
		"startIntroPart2": "Great Prince Bismarck, the German people look up to you to lead them to greater days of glory. Their determination is strong, and now they turn to you, their beloved iron chancellor, to guide them once more. Will you rule and conquer through blood and iron, or foster the Germanic arts and industry? Can you build a civilization that will stand the test of time?",
		"declaringWar": "I cannot wait until ye grow even mightier. Therefore, prepare for war!",
		"attacked": "Corrupted villain! We will bring you into the ground!",
		"defeated": "Germany has been destroyed. I weep for the future generations.",
		"introduction": "Guten tag. In the name of the great German people, I bid you welcome.",
		"neutralHello": "What now?",
		"hateHello": "So, out with it!",
		"tradeRequest": "It would be in your best interest, to carefully consider this proposal.",
		"outerColor": [150,150,150],
		"innerColor": [60,60,60],
		"favoredReligion": "Christianity",
		"uniqueName": "Furor Teutonicus",
		"uniques": ["When conquering an encampment, earn [25] Gold and recruit a Barbarian unit <with [67]% chance>",
			"[-25]% maintenance costs <for [Land] units>",
			    "[+5 Faith, +5 Gold, +5 Culture, +5 Happiness, +5 Production, +5 Science] from [All] tiles [in all cities]",
			    "[+10 Culture] from [All] tiles [in all cities]","[+10 Gold] from [All] tiles [in all cities]",
			    "[+10 Faith] from [All] tiles [in all cities]","[+10 Production] from [All] tiles [in all cities]",
			    "[+10 Science] from [All] tiles [in all cities]","[+10 Happiness] from [All] tiles [in all cities]",
			    "May choose [1] additional belief(s) of any type when [founding] a religion"],
		"cities": ["Berlin","Hamburg","Munich","Cologne","Frankfurt","Essen","Dortmund","Stuttgart","Düsseldorf","Bremen",
			"Hannover","Duisburg","Leipzig","Dresden","Bonn","Bochum","Bielefeld","Karlsruhe","Gelsenkirchen","Wiesbaden",
			"Münster","Rostock","Chemnitz","Braunschweig","Halle","Mönchengladbach","Kiel","Wuppertal","Freiburg","Hagen",
			"Erfurt","Kaiserslautern","Kassel","Oberhausen","Hamm","Saarbrücken","Krefeld","Pirmasens","Potsdam","Solingen",
			"Osnabrück","Ludwigshafen","Leverkusen","Oldenburg","Neuss","Mülheim","Darmstadt","Herne","Würzburg",
			"Recklinghausen","Göttingen","Wolfsburg","Koblenz","Hildesheim","Erlangen"]
	},

	{
		"name": "The Ottomans",
		"leaderName": "Suleiman I",
		"adjective": ["Ottoman"],
		"startBias": ["Coast"],
		"preferredVictoryType": "Domination",

		"startIntroPart1": "Blessings of God be upon you, oh Great Emperor Suleiman! Your power, wealth and generosity awe the world! Truly, are you called 'Magnificent!' Your empire began in Bithynia, a small country in Eastern Anatolia in 12th century. Taking advantage in the decline of the great Seljuk Sultanate of Rum, King Osman I of Bithynia expanded west into Anatolia. Over the next century, your subjects brought down the empire of Byzantium, taking its holdings in Turkey and then the Balkans. In the mid 15th century, the Ottomans captured ancient Constantinople, gaining control of the strategic link between Europe and the Middle East. Your people's empire would continue to expand for centuries governing much of North Africa, the Middle East and Eastern Europe at its height.",
		"startIntroPart2": "Mighty Sultan, heed the call of your people! Bring your empire back to the height of its power and glory and once again the world will look upon your greatness with awe and admiration! Will you accept the challenge, great emperor? Will you build an empire that will stand the test of time?",
		"declaringWar": "Your continued insolence and failure to recognize and preeminence leads us to war.",
		"attacked": "Good. The world shall witness the incontestable might of my armies and the glory of the Empire.",
		"defeated": "Ruin! Ruin! Istanbul becomes Iram of the Pillars, remembered only by the melancholy poets.",
		"introduction": "From the magnificence of Topkapi, the Ottoman nation greets you, stranger! I'm Suleiman, Kayser-I Rum, and I bestow upon you my welcome!",
		"neutralHello": "Greetings!",
		"hateHello": "What do you want?",
		"tradeRequest": "Let us do business! Would you be interested?",
		"outerColor": [245,248,185],
		"innerColor": [18,84,30],
		"favoredReligion": "Islam",
		"uniqueName": "Barbary Corsairs",
		"uniques": ["[-66]% maintenance costs <for [Water] units>",
			"When defeating a [{Barbarian} {Water}] unit, earn [25] Gold and recruit it <with [50]% chance>",
			    "[+5 Faith, +5 Gold, +5 Culture, +5 Happiness, +5 Production, +5 Science] from [All] tiles [in all cities]",
			    "[+10 Culture] from [All] tiles [in all cities]","[+10 Gold] from [All] tiles [in all cities]",
			    "[+10 Faith] from [All] tiles [in all cities]","[+10 Production] from [All] tiles [in all cities]",
			    "[+10 Science] from [All] tiles [in all cities]","[+10 Happiness] from [All] tiles [in all cities]",
			    "May choose [1] additional belief(s) of any type when [founding] a religion"],
		"cities": ["Istanbul","Edirne","Ankara","Bursa","Konya","Samsun","Gaziantep","Diyarbakır","Izmir","Kayseri","Malatya",
			"Mersin","Antalya","Zonguldak","Denizli","Ordu","Muğla","Eskişehir","Inebolu","Sinop","Adana","Artvin",
			"Bodrum","Eregli","Silifke","Sivas","Amasya","Marmaris","Trabzon","Erzurum","Urfa","Izmit","Afyonkarahisar",
			"Bitlis","Yalova"]
	},
	{
		"name": "Korea",
		"leaderName": "Sejong",
		"adjective": ["Korean"],
		"startBias": ["Coast"],
		"preferredVictoryType": "Scientific",

		"startIntroPart1": "Greetings to you, exalted King Sejong the Great, servant to the people and protector of the Choson Dynasty! Your glorious vision of prosperity and overwhelming benevolence towards the common man made you the most beloved of all Korean kings. From the earliest days of your reign, the effort you took to provide a fair and just society for all was surpassed only by the technological advances spurred onwards by your unquenched thirst for knowledge. Guided by your wisdom, the scholars of the Jade Hall developed Korea's first written language, Hangul, bringing the light of literature and science to the masses after centuries of literary darkness.",
		"startIntroPart2": "Honorable Sejong, once more the people look to your for guidance. Will you rise to the occasion, bringing harmony and understanding to the people? Can you once again advance your kingdom's standing to such wondrous heights? Can you build a civilization that stands the test of time?",
		"declaringWar": "Jip-hyun-jun (Hall of Worthies) will no longer tolerate your irksome behavior. We will liberate the citizens under your oppression even with force, and enlighten them!",
		"attacked": "Foolish, miserable wretch! You will be crushed by this country's magnificent scientific power!",
		"defeated": "Now the question is who will protect my people. A dark age has come.",
		"introduction": "Welcome to the palace of Choson, stranger. I am the learned King Sejong, who looks after his great people.",

		"neutralHello": "Hello.",
		"hateHello": "Oh, it's you",
		"tradeRequest": "We have many things to discuss and have much to benefit from each other.",
		"outerColor": [26,32,96],
		"innerColor": [255,0,0],
		"favoredReligion": "Confucianism",
		"uniqueName": "Scholars of the Jade Hall",
        "uniques": ["[+2 Science] from every specialist [in all cities]", "[+2 Science] from every [Great Improvement]","Receive a tech boost when scientific buildings/wonders are built in capital",
			    "[+5 Faith, +5 Gold, +5 Culture, +5 Happiness, +5 Production, +5 Science] from [All] tiles [in all cities]",
			    "[+10 Culture] from [All] tiles [in all cities]","[+10 Gold] from [All] tiles [in all cities]",
			    "[+10 Faith] from [All] tiles [in all cities]","[+10 Production] from [All] tiles [in all cities]",
			    "[+10 Science] from [All] tiles [in all cities]","[+10 Happiness] from [All] tiles [in all cities]",
			    "May choose [1] additional belief(s) of any type when [founding] a religion"],
		"cities": ["Seoul","Busan","Jeonju","Daegu","Pyongyang","Kaesong","Suwon","Gwangju","Gangneung","Hamhung","Wonju","Ulsan",
			"Changwon","Andong","Gongju","Haeju","Cheongju","Mokpo","Dongducheon","Geoje","Suncheon","Jinju","Sangju",
			"Rason","Gyeongju","Chungju","Sacheon","Gimje","Anju"]
	}	
]
			   
			   
			   
			   [
    {
        "name": "Tradition",
        "era": "Ancient era",
        "priorities": {
            "Neutral": 40,
            "Cultural": 40,
            "Diplomatic": 0,
            "Domination": 0,
            "Scientific": 40
        },
        "uniques": [
            "[+3 Culture] [in capital]",
            "[-25]% Culture cost of natural border growth [in all cities]"
        ],
        "policies": [
            {
                "name": "Aristocracy",
                "uniques": [
                    "[+15]% Production when constructing [All] wonders [in all cities]",
                    "[+1 Happiness] per [10] population [in all cities]"
                ],
                "row": 1,
                "column": 1
            },
            {
                "name": "Legalism",
                "uniques": [
                    "Provides the cheapest [Culture] building in your first [4] cities for free"
                ],
                "row": 1,
                "column": 3
            },
            {
                "name": "Oligarchy",
                "uniques": [
                    "Units in cities cost no Maintenance",
                    "[+100]% Strength for cities <with a garrison> <when attacking>"
                ],
                "row": 1,
                "column": 5
            },
            {
                "name": "Landed Elite",
                "uniques": [
                    "[+10]% growth [in capital]",
                    "[+2 Food] [in capital]"
                ],
                "requires": ["Legalism"],
                "row": 2,
                "column": 2
            },
            {
                "name": "Monarchy",
                "uniques": [
                    "[+1 Gold, +1 Happiness] per [2] population [in capital]"
                ],
                "requires": ["Legalism"],
                "row": 2,
                "column": 4
            },
            {
                "name": "Tradition Complete",
                "uniques": [
                    "[+15]% growth [in all cities]",
                    "[+2 Food] [in all cities]"
                ]
            }
        ]
    },
    {
        "name": "Liberty",
        "era": "Ancient era",
        "priorities": {
            "Neutral": 40,
            "Cultural": 0,
            "Diplomatic": 40,
            "Domination": 40,
            "Scientific": 0
        },
        "uniques": ["[+1 Culture] [in all cities]"],
        "policies": [

            {
                "name": "Collective Rule",
                "uniques": [
                    "[+50]% Production when constructing [Settler] units [in capital]",
                    "Free [Settler] appears"
                ],
                "row": 1,
                "column": 1
            },
            {
                "name": "Citizenship",
                "uniques": [
                    "[-25]% tile improvement construction time",
                    "Free [Worker] appears"
                ],
                "row": 1,
                "column": 4
            },
            {
                "name": "Republic",
                "uniques": [
                    "[+1 Production] [in all cities]",
                    "[+5]% Production when constructing [All] buildings [in all cities]"
                ],
                "requires": ["Collective Rule"],
                "row": 2,
                "column": 1
            },
            {
                "name": "Representation",
                "uniques": [
                    "Each city founded increases culture cost of policies [33]% less than normal",
                    "Empire enters golden age"
                ],
                "requires": ["Citizenship"],
                "row": 2,
                "column": 3
            },
            {
                "name": "Meritocracy",
                "uniques": [
                    "[+1 Happiness] [in all cities connected to capital]",
                    "[-5]% Unhappiness from [Population] [in all non-occupied cities]"
                ],
                "requires": ["Citizenship"],
                "row": 2,
                "column": 5
            },
            {
                "name": "Liberty Complete",
                "uniques": ["Free Great Person"]
            }
        ]
    },
    {
        "name": "Honor",
        "era": "Ancient era",
        "priorities": {
            "Neutral": 0,
            "Cultural": 0,
            "Diplomatic": 0,
            "Domination": 10,
            "Scientific": 0
        },
        "uniques": [
            "[+33]% Strength <vs [Barbarian] units>",
            "Earn [100]% of killed [Barbarian] unit's [Strength] as [Culture]",
            "Notified of new Barbarian encampments"
        ],
        "policies": [
            {
                "name": "Warrior Code",
                "uniques": [
                    "[+15]% Production when constructing [Melee] units [in all cities]",
                    "Free [Great General] appears"
                ],
                "row": 1,
                "column": 2
            },
            {
                "name": "Discipline",
                "uniques": [
                    "[+10]% Strength <for [Melee] units> <when adjacent to a [Melee] unit>"
                ],
                "row": 1,
                "column": 4
            },
            {
                "name": "Military Tradition",
                "uniques": [
                    "[+50]% XP gained from combat <for [Military] units>"
                ],
                "requires": ["Warrior Code"],
                "row": 2,
                "column": 2
            },
            {
                "name": "Military Caste",
                "uniques": [
                    "[+1 Happiness, +2 Culture] [in all cities with a garrison]"
                ],
                "requires": ["Discipline"],
                "row": 2,
                "column": 4
            },
            {
                "name": "Professional Army",
                "uniques": [
                    "[-33]% Gold cost of upgrading <for [Military] units>",
                    "[+1 Happiness] from every [Walls]",
                    "[+1 Happiness] from every [Castle]",
                    "[+1 Happiness] from every [Arsenal]",
                    "[+1 Happiness] from every [Military Base]"
                ],
                "requires": ["Military Caste"],
                "row": 3,
                "column": 4
            },
            {
                "name": "Honor Complete",
                "uniques": [
                    "Earn [10]% of killed [Military] unit's [Cost] as [Gold]"
                ]
            }
        ]
    },
    {
        "name": "Piety",
        "era": "Classical era",
        "priorities": {
            "Neutral": 0,
            "Cultural": 10,
            "Diplomatic": 0,
            "Domination": 0,
            "Scientific": 0
        },
        "uniques": [
            "[+15]% Production when constructing [Culture] buildings [in all cities]",
            "Only available <before adopting [Rationalism]>"
        ],
        "policies": [
            {
                "name": "Organized Religion",
                "uniques": [
                    "[+1 Happiness] from every [Monument]",
                    "[+1 Happiness] from every [Temple]",
                    "[+1 Happiness] from every [Monastery]"
                ],
                "row": 1,
                "column": 2
            },
            {
                "name": "Mandate Of Heaven",
                "uniques": ["[50]% of excess happiness converted to [Culture]"],
                "row": 1,
                "column": 5
            },
            {
                "name": "Theocracy",
                "uniques": ["[+10]% [Gold] from every [Temple]"],
                "requires": ["Organized Religion"],
                "row": 2,
                "column": 1
            },
            {
                "name": "Reformation",
                "uniques": [
                    "[+33]% [Culture] [in all cities with a world wonder]",
                    "Empire enters golden age"
                ],
                "requires": ["Organized Religion"],
                "row": 2,
                "column": 3
            },
            {
                "name": "Free Religion",
                "uniques": [
                    "Free Social Policy",
                    "[+1 Culture] from every [Monument]",
                    "[+1 Culture] from every [Temple]",
                    "[+1 Culture] from every [Monastery]"
                ],
                "requires": ["Mandate Of Heaven", "Reformation"],
                "row": 3,
                "column": 4
            },
            {
                "name": "Piety Complete",
                "uniques": [
                    "[-10]% Culture cost of adopting new Policies"
                ]
            }
        ]
    },
    {
        "name": "Patronage",
        "era": "Medieval era",
        "priorities": {
            "Neutral": 0,
            "Cultural": 0,
            "Diplomatic": 20,
            "Domination": 0,
            "Scientific": 0
        },
        "uniques": ["[-25]% City-State Influence degradation"],
        "policies": [
            {
                "name": "Philantropy",
                "uniques": [
                    "Gifts of Gold to City-States generate [25]% more Influence"
                ],
                "row": 1,
                "column": 2
            },
            {
                "name": "Aesthetics",
                "uniques": [
                    "Resting point for Influence with City-States is increased by [20]"
                ],
                "row": 1,
                "column": 4
            },
            {
                "name": "Scholasticism",
                "uniques": [
                    "Allied City-States provide [Science] equal to [25]% of what they produce for themselves"
                ],
                "requires": ["Philantropy"],
                "row": 2,
                "column": 2
            },
            {
                "name": "Cultural Diplomacy",
                "uniques": [
                    "[+100]% resources gifted by City-States",
                    "[+50]% Happiness from luxury resources gifted by City-States"
                ],
                "requires": ["Scholasticism"],
                "row": 3,
                "column": 2
            },
            {
                "name": "Educated Elite",
                "requires": ["Scholasticism", "Aesthetics"],
                "uniques": [
                    "Allied City-States will occasionally gift Great People"
                ],
                "row": 3,
                "column": 4
            },
            {
                "name": "Patronage Complete",
                "uniques": [
                    "Influence of all other civilizations with all city-states degrades [33]% faster",
                    "Triggers the following global alert: [Our influence with City-States has started dropping faster!]"
                ]
            }
        ]
    },
    {
        "name": "Commerce",
        "era": "Medieval era",
        "priorities": {
            "Neutral": 0,
            "Cultural": 10,
            "Diplomatic": 10,
            "Domination": 20,
            "Scientific": 10
        },
        "uniques": ["[+25]% [Gold] [in capital]"],
        "policies": [
            {
                "name": "Naval Tradition",
                "uniques": [
                    "[+1] Movement <for [{Military} {Water}] units>",
                    "[+1] Sight <for [{Military} {Water}] units>",
                    "Free [Great General] appears"
                    // "[+2] Movement <for [Great Admiral] units>"
                    // ToDo: Should be "Free [Great Admiral] appears"
                ],
                "row": 1,
                "column": 2
            },
            {
                "name": "Trade Unions",
                "uniques": [
                    "[-33]% maintenance on road & railroads",
                    "[+1 Gold] from every [Harbor]",
                    "[+1 Gold] from every [Seaport]"
                ],
                "row": 1,
                "column": 4
            },
            {
                "name": "Merchant Navy",
                "uniques": ["[+3 Production] [in all coastal cities]"],
                "requires": ["Naval Tradition"],
                "row": 2,
                "column": 2
            },
            {
                "name": "Mercantilism",
                "uniques": [
                    "[Gold] cost of purchasing items in cities [-25]%",
                    "[+1 Science] from every [Mint]",
                    "[+1 Science] from every [Market]",
                    "[+1 Science] from every [Bank]",
                    "[+1 Science] from every [Stock Exchange]"
                ],
                "requires": ["Trade Unions"],
                "row": 2,
                "column": 4
            },
            {
                "name": "Protectionism",
                "uniques": ["[+1] Happiness from each type of luxury resource"],
                "requires": ["Mercantilism"],
                "row": 3,
                "column": 4
            },
            {
                "name": "Commerce Complete",
                "uniques": [
                    "[+1 Gold] from every specialist [in all cities]"
                ]
            }
        ]
    },
    {
        "name": "Rationalism",
        "era": "Renaissance era",
        "priorities": {
            "Neutral": 0,
            "Cultural": 10,
            "Diplomatic": 0,
            "Domination": 0,
            "Scientific": 20
        },
        "uniques": [
            "Science gained from research agreements [+50]%"
            "Only available <before adopting [Piety]>"
        ],
        "policies": [
            {
                "name": "Secularism",
                "uniques": [
                    "[+2 Science] from every specialist [in all cities]"
                ],
                "row": 1,
                "column": 2
            },
            {
                "name": "Humanism",
                "uniques": [
                    "[+1 Happiness] from every [University]",
                    "[+1 Happiness] from every [Observatory]",
                    "[+1 Happiness] from every [Public School]"
                ],
                "row": 1,
                "column": 5
            },
            {
                "name": "Free Thought",
                "uniques": [
                    "[+1 Science] from every [Trading post]",
                    "[+17]% [Science] from every [University]"
                ],
                "requires": ["Secularism"],
                "row": 2,
                "column": 1
            },
            {
                "name": "Sovereignty",
                "uniques": ["[+15]% [Science] <while the empire is happy>"],
                "requires": ["Humanism"],
                "row": 2,
                "column": 5
            },
            {
                "name": "Scientific Revolution",
                "uniques": ["[2] Free Technologies"],
                "requires": ["Free Thought"],
                "row": 3,
                "column": 1
            },
            {
                "name": "Rationalism Complete",
                "uniques": [
                    "[+1 Gold] from all [Science] buildings",
                ]
            }
        ]
    },
    {
        "name": "Freedom",
        "era": "Medieval era",
        "priorities": {
            "Neutral": 30,
            "Cultural": 30,
            "Diplomatic": 20,
            "Domination": 0,
            "Scientific": 20
        },
        "uniques": [
            "[+25]% Great Person generation [in all cities]",
            "Only available <before adopting [Autocracy]>"
        ],
        "policies": [
            {
                "name": "Constitution",
                "uniques": ["[+2 Culture] from every [Wonder]"],
                "row": 1,
                "column": 1
            },
            {
                "name": "Universal Suffrage",
                "uniques": ["[+33]% Strength for cities <when defending>"],
                "row": 1,
                "column": 3
            },
            {
                "name": "Civil Society",
                "uniques": [
                    "[-50]% Food consumption by specialists [in all cities]"
                ],
                "row": 1,
                "column": 5
            },
            {
                "name": "Free Speech",
                "uniques": ["[8] units cost no maintenance"],
                "requires": ["Constitution"],
                "row": 2,
                "column": 1
            },
            {
                "name": "Democracy",
                "uniques": [
                    "[-50]% Unhappiness from [Specialists] [in all cities]"
                ],
                "requires": ["Civil Society"],
                "row": 2,
                "column": 5
            },
            {
                "name": "Freedom Complete",
                "uniques": [
                    "[+100]% Yield from every [Great Improvement]",
                    "[+50]% Golden Age length",
                ]
            }
        ]
    },
    {
        "name": "Autocracy",
        "era": "Medieval era",
        "priorities": {
            "Neutral": 30,
            "Cultural": 0,
            "Diplomatic": 0,
            "Domination": 30,
            "Scientific": 0
        },
        "uniques": [
            "[-33]% maintenance costs <for [All] units>",
            "Only available <before adopting [Freedom]>"
        ],
        "policies": [
            {
                "name": "Populism",
                "uniques": ["[+25]% Strength <for [Wounded] units>"],
                "row": 1,
                "column": 1
            },
            {
                "name": "Militarism",
                "uniques": ["[Gold] cost of purchasing [All] units [-33]%"],
                "row": 1,
                "column": 5
            },
            {
                "name": "Fascism",
                "uniques": [
                    "Quantity of strategic resources produced by the empire +[100]%",
                ],
                "requires": ["Populism", "Militarism"],
                "row": 2,
                "column": 3
            },
            {
                "name": "Police State",
                "uniques": [
                    "[+3 Happiness] from every [Courthouse]",
                    "[+100]% Production when constructing [Courthouse] buildings [in all cities]"
                ],
                "requires": ["Militarism"],
                "row": 2,
                "column": 5
            },
            {
                "name": "Total War",
                "uniques": [
                    "[+15]% Production when constructing [Military] units [in all cities]",
                    "New [Military] units start with [15] Experience [in all cities]"
                ],
                "requires": ["Police State", "Fascism"],
                "row": 3,
                "column": 4
            },
            {
                "name": "Autocracy Complete",
                "uniques": [
                    "[+25]% Strength <when attacking> <for [Military] units> <for [30] turns>"
                ]
            }
        ]
    },
    {
        "name": "Order",
        "era": "Medieval era",
        "priorities": {
            "Neutral": 30,
            "Cultural": 0,
            "Diplomatic": 30,
            "Domination": 0,
            "Scientific": 20
        },
        "uniques": [
            "[+3 Happiness] [in all cities]",
        ],
        "policies": [
            {
                "name": "United Front",
                "uniques": [
                    "Militaristic City-States grant units [3] times as fast when you are at war with a common nation"
                ],
                "row": 1,
                "column": 1
            },
            {
                "name": "Planned Economy",
                "uniques": [
                    "[+25]% [Science] from every [Factory]"
                ],
                "row": 1,
                "column": 3
            },
            {
                "name": "Nationalism",
                "uniques": [
                    "[+15]% Strength <for [All] units> <when fighting in [Friendly Land] tiles>"
                ],
                "row": 1,
                "column": 5
            },
            {
                "name": "Socialism",
                "requires": ["Planned Economy"],
                "uniques": [
                    "[-15]% maintenance cost for buildings [in all cities]"
                ],
                "row": 2,
                "column": 3
            },
            {
                "name": "Communism",
                "requires": ["Socialism"],
                "uniques": [
                    "[+1 Production] [in all cities]",
                    "[+10]% Production when constructing [All] buildings [in all cities]",
                    "[+1 Production] from every [Quarry]"
                ],
                "row": 3,
                "column": 3
            },
            {
                "name": "Order Complete",
                "uniques": [
                    "[+1 Food, +1 Production, +1 Science, +1 Gold, +1 Culture] [in all cities]"
                ]
            }
        ]
    }
]
			   
			   
			   
			   
			   
			   

			   
			   
			   
			 
			   
