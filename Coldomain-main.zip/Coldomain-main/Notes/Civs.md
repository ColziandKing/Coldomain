Intro
  
	Part I
# Azibhania Empire
  
   Cities: "Azibhania Fortspance","Uemsphire Citadel","Ravimines Deposit"
  	Out & In Color: 
	Unique Name: "Domination & Submission"
	Uniques: "Receive free [Great Engineer] when you discover [Engineering]","[+2 Production] from every [Mountain]"
	
# Chediluen
  
   Cities: "Hopiia","Lantennant"
  	Out & In Color: 
	Unique Name: "Republic Freedom"
	Uniques: "Receive a free [Great Prophet] when you discover [Theology]","[+2 Food] from every [Mountain]"
	
# Eisnia Archipelago
  
   Cities: 
  	Out & In Color: 
	Unique Name: "Expedition Alliance"
	Uniques: "Receive a free [Great Merchant] when you discover [Currency]","[+2 Gold] from every [Mountain]"
	
# Umiratie Dynasty
  
   Cities: "Umiratie Landscape","Caravansary Company","Harimyar Harvest Hills","Ountain Generator","Spirit Fills"
  	Out & In Color: 0,204,0 Green & | Out  41,83,42], In[146,221,9
	Unique Name: "Cultural Conquest"
	Uniques: "Receive free [Great Artist] when you discover [Drama and Poetry]","[+2 Culture] from every [Mountain]"
	
# Ziandestria
  Hailing from Ziandestria, A nation realm with its advance foundations. Leading people to the future with science. Remembering that the past builds the future
  For science and love, making haste for future discovery. Fulfilling destiny not by pride but with trust of guidance and wisdom.
   Cities: "Ziandestria","Kenth","Ilumaran Irath","Giraceus","Fleyjanite Angnariant","Estria-Ziand","Thertral","Sunianoonaries","Arigamoto","Fyangh"
  	Out & In Color: Green & Cyan
	Unique Name: "Scientific Sanctuary States"
	Uniques: "Receive a free [Great Scientist] when you discover [Philosophy]","[+2 Science] from every [Mountain]"
	
	Part II
# Colziand
  
   Cities: "Colziane", "Cher-Hon Rishvas", "Rekle-Esieg", "Erion Faith", "Colvian", "Caballeron", "Lead-Diah", "Ravdon Mond", "Sabert Zhang", 
			   "Colziantozant", "Adophant", "Coldelton", "Mega Complexcity", "Sheeno"
  	Out & In Color: 
	Unique Name: "Cool Kingdom"
	Uniques: "[+1 Science] from [All] tiles [in all cities]", "Starts with [Archery]","Starts with [Trapping]"
	
# Fullysia
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "Starts with [Animal Husbandry]","Starts with [The Wheel]","[+1 Faith] from [All] tiles [in all cities]"
	
# Salveo
  
   Cities: "Leonorre","Leo Volt","Seon-Voe","Leono","Leona","Le Nova","Sardaze"
  	Out & In Color: 
	Unique Name: 
	Uniques: "Starts with [Mining]","Starts with [Bronze Working]","[+1 Production] from [All] tiles [in all cities]"
	
# Salumi
  
   Cities: "Saludonia","Saludon","Libro Saldos","Saludos","Villavicencio", "Medellin","Cali", "Santa Marianna", "Buenaventura", "San Andres", "Peacesee", 
			   "Sofia", "Leticia","Sal Kristell","Sal Kristina","Paula","Libra Saldine","Baconilla","Hamburger","Duke Baloney"
  	Out & In Color: 
	Unique Name: "Salumi Feminine Love"
	Uniques: "[+1 Culture, +1 Happiness] from [All] tiles [in all cities]","Starts with [Calendar]"
	
# Suzainswellia
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "Starts with [Pottery]","Starts with [Sailing]", "[+1 Food, +1 Gold] from [All] tiles [in all cities]"
	
	Part III
# Arxemlio    
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "Starts with [Masonry]"
	
# Magroonaguio 
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "Cannot build [Settler] units","Receive a free [Great General] when you discover [Horseback Riding]"
	
# Palneothic
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "[+2 Faith] from every [Mountain]"
	
# Relmorgius
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "Starts with [Writing]"
	
# Syndria Operations
  
   Cities: 
  	Out & In Color: 
	Unique Name: 
	Uniques: "[+2 Happiness] from every [Mountain]"
	
# City-States
	Winssefa, Orlhium, Eshgor, Dorgainnodus, Servwhann
	
Outro
