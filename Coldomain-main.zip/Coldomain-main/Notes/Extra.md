Fullysia "Starts with [Animal Husbandry]","Starts with [The Wheel]"
	Suzainswellia "Starts with [Pottery]","Starts with [Sailing]"
	"Starts with [Mining]","Starts with [Bronze Working]"
	"Starts with [Writing]","Starts with [Calendar]"
	"Starts with [Archery]","Starts with [Trapping]"
"[-100]% Culture cost of adopting new Policies",
			    "[+1 Food, +1 Gold, +1 Production, +1 Culture, +1 Faith, +1 Happiness] from [All] tiles [in all cities]",
			    "Starts with [Pottery]","Starts with [Animal Husbandry]","Starts with [Mining]","Starts with [The Wheel]","Starts with [Globalization]"]
For difficulty
 "[+1 Food, +1 Gold, +1 Production, +1 Culture, +1 Faith, +1 Happiness] from [All] tiles [in all cities]",
			    "[-50]% Culture cost of adopting new Policies","Starts with [Pottery]","Starts with [Animal Husbandry]","Starts with [Mining]",
			    "Starts with [The Wheel]","Starts with [Nuclear Fusion]","Starts with [Atomic Theory]"]
			    
			    "Starts with [Mobile Tactics]"
			    
			    "Starts with [Lasers]","Starts with [Electricity]"
  outbreak company
        o, 25 51
	+5 Science, +5 Food, +5 Gold, +5 Production, +5 Culture, +5 Faith, +5 Happiness] from [All] tiles [in all cities],
	"All newly-trained [relevant] units receive the [Blitz] promotion",
Belief pairs
Ancestor Worship and god king, earth mother and Faith Healers, Fertility Rites and God of the Open Sky, god of craftsmen and war, 
    sacred path and waters, oral tradition and one with nature, religious idols and settlements,  monument and messenger of the gods,
    goddess of love and festivals, Dance of the Aurora and god of the seas, desert folklore and stone circles
 in which your mother's family is from

    Pantheon: Sun & Tears of God, , 
 yellow ray, blue uzaine, red ulyssia
	masonry?
    

    Originally Worlds Universe, mammoth and gauchos

    industrial  


    as miss beezlebub likes

    City-state no settlers "[+30]% Strength for cities <when attacking>", a great defense but can have its own cities if given settlers, a suzerainee

 255,51,255],red
		"innerColor": [255,0,0 pink
		255,255,0],yellow
		"innerColor": [255,128,0 orange
		128,255,0],divinestria lighter green
		"innerColor": [0,255,255 light blue
unused each great person receive for research techs( replacement for mayan calendar unique

medieval vietnam unique was used all but not for CHampa and Hungary
ancient sumer israel hittite epirus
